package com.mycompany.pedido;

/**
 *
 * @author Larissa
 */
public class Pedido {
    private String produto;
    private int quantidade;
    private boolean freteExpresso;
    private String cupomDesconto;

    private Pedido(Builder builder) {
        this.produto = builder.produto;
        this.quantidade = builder.quantidade;
        this.freteExpresso = builder.freteExpresso;
        this.cupomDesconto = builder.cupomDesconto;
    }

    public static class Builder {
        private String produto;
        private int quantidade;
        private boolean freteExpresso = false;
        private String cupomDesconto = "";

        public Builder(String produto, int quantidade) {
            if (produto == null || produto.isEmpty()) {
                throw new IllegalArgumentException("Produto não pode ser vazio");
            }
            if (quantidade <= 0) {
                throw new IllegalArgumentException("Quantidade deve ser maior que zero");
            }
            this.produto = produto;
            this.quantidade = quantidade;
        }

        public Builder freteExpresso(boolean freteExpresso) {
            this.freteExpresso = freteExpresso;
            return this;
        }

        public Builder cupomDesconto(String cupomDesconto) {
            this.cupomDesconto = cupomDesconto;
            return this;
        }

        public Pedido build() {
            return new Pedido(this);
        }
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "produto='" + produto + '\'' +
                ", quantidade=" + quantidade +
                ", freteExpresso=" + freteExpresso +
                ", cupomDesconto='" + cupomDesconto + '\'' +
                '}';
    }
}
