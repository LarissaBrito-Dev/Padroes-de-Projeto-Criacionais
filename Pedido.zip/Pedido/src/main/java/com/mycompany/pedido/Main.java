package com.mycompany.pedido;
/**
 *
 * @author Larissa
 */
public class Main {
    public static void main(String[] args) {
        Pedido pedido1 = new Pedido.Builder("Notebook", 2)
                .freteExpresso(true)
                .cupomDesconto("DESCONTO10")
                .build();
        Pedido pedido2 = new Pedido.Builder("Mouse", 1)
                .build();
        System.out.println(pedido1);
        System.out.println(pedido2);
    }
}
